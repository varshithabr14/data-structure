//pgm to declare an array 

#include <stdio.h>

int main()
{
    int arr[], i,n;
    for i=1;i<n-1;i;
    printf("%d",i)
    if(n=1,arr)
    
    return 0;
}
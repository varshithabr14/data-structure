//array pgm to declare//

#include <stdio.h>

int main()
{
    int arr[5]={ 10,20,30,40,50};
    printf("enter an element");
    printf("%d",&arr[i]);
    if(arr();
    return 0;
}
//array pgm to declare//

#include <stdio.h>

int main()
{
    int arr[5]={ 10,20,30,40,50};
    printf("%d",&arr);
    return 0;
}
